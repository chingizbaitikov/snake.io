import express from 'express';
import http from 'http';
import socketIO from 'socket.io';

const server = express();
const httpServer = http.createServer(expressServer);
const ioServer = socketIO(httpServer);

const port = 80;
const tick = 33.3;

expressServer.use(express.static('public'));

ioServer.on('connection', socket => {
    console.log('A new player connected with id ${socket.id');

    socket.on('spawn',()=>{
        //TODO Find Base. Disconnect
        //TODO Response to commands

        socket.on('command', key=>{
            switch(key){
                case 'w':

                    break;
                case 'a':

                    break;
                case 's':

                    break;
                case 'd':

                    break;
            }
        });

        socket.on('disconnect',reason =>{
            console.log('The player with id ${socket.id} has disconnected. \nReason: ${reason}.');
            //TODO Make the snake dead

    });


    })
});

setInterval(()=>{
    //TODO MOve snakes
    ioServer.emit('update', 'TODO: replace with real snake data');
}, tick);

httpServer.listen(port,()=> console.log('Snake listening on port ${port}.'));